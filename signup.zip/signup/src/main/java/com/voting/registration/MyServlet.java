package com.voting.registration;
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MyServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve data from the request parameters (GET method)
        String name = request.getParameter("name");
        String age = request.getParameter("age");
        
        // Process the data
        String message = "Hello, " + name + "! You are " + age + " years old.";
        
        // Set the response content type
        response.setContentType("text/html");
        
        // Write the response message
        response.getWriter().println("<h1>" + message + "</h1>");
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve data from the request parameters (POST method)
        String name = request.getParameter("name");
        String age = request.getParameter("age");
        
        // Process the data
        String message = "Hello, " + name + "! You are " + age + " years old.";
        
        // Set the response content type
        response.setContentType("text/html");
        
        // Write the response message
        response.getWriter().println("<h1>" + message + "</h1>");
    }
}
