create database voting;
use voting;
create table users(Id int primary key auto_increment,
uname varchar(30),
uvid varchar(30),
upass varchar(20),
umobile varchar(20));
desc users;
select * from users;
create table admin(Id int primary key auto_increment,
email varchar(20),
passw varchar(20));
insert into admin(email,passw) values('Prasanna','1811');
insert into admin(email,passw) values('Samruddhi','2808');
desc admin;
update admin 
set email='prasannachandratre@gmail.com'
where Id='1';
update admin 
set email='samuj8789@gmail.com'
where Id='2';
alter table admin
modify column email varchar(50);
select * from admin;
select * from users;
create table candidate(id int primary key auto_increment,
name varchar(30),
pname varchar(20),
dob date,
mobile varchar(20));
desc candidate;
select * from candidate;
create table result(votes varchar(50));
select * from result;
select * from result;